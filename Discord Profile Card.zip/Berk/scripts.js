var canvas = document.createElement('canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
document.getElementById('background').appendChild(canvas);
var context = canvas.getContext('2d');

var stars = [];
var numStars = 500;

// Yıldızların özellikleri
for (var i = 0; i < numStars; i++) {
    var x = Math.random() * canvas.width;
    var y = Math.random() * canvas.height;
    var size = Math.random() * 3;
    var speed = Math.random() * 0.5;
    stars.push({x: x, y: y, size: size, speed: speed});
}

function draw() {
    // Arka plan rengi
    context.fillStyle = '#111214';
    context.fillRect(0, 0, canvas.width, canvas.height);

    // Yıldızları çizme
    for (var i = 0; i < numStars; i++) {
        var star = stars[i];
        context.beginPath();
        context.arc(star.x, star.y, star.size, 0, 2 * Math.PI);
        context.fillStyle = 'white';
        context.fill();
    }
}

function animate() {
    // Yıldızları hareket ettirme
    for (var i = 0; i < numStars; i++) {
        var star = stars[i];
        star.x -= star.speed;
        if (star.x < -star.size) {
            star.x = canvas.width + star.size;
        }
    }

    draw();
    requestAnimationFrame(animate);
}

animate();
